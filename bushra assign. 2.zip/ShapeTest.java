public class ShapeTest {
    public static void main(String[] args) {
        Rectangle r = new Rectangle("Blue", true, 5.0, 5.0);
        Circle c = new Circle("Red", true, 5.0);

    }
}
