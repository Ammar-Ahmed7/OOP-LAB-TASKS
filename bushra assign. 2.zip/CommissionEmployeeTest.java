public class CommissionEmployeeTest {
    public static void main(String[] args) {
       // CommissionEmployee c = new CommissionEmployee("Talal", "Ahmed", "321", 40.0, 0.1);
        HourlyEmployee h = new HourlyEmployee("Fahad", "Ajmal", "2346799", 3.00, 1.5 );
        System.out.println(h.toString());
    }
}
