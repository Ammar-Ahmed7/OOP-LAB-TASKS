public class BasePlusCommissionEmployeeTest {
    public static void main(String[] args) {
        BasePlusCommissionEmployee b = new BasePlusCommissionEmployee("yahya", "irfan", "123.0", 45.0, 0.1, 500.0);
        System.out.println(b.toString());
    }
}
